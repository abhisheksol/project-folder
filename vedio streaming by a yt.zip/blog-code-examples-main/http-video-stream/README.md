# How to run
```
npm install
npm start
```

### Bonus Challenge
You can decide how much data to actually give back to the browser
instead of streaming the whole video like Chrome asks.

Can you figure out how to make the chunk size 10kb per request?