# ReasonReact Form Example

## How to run
### Install and compile reasonml code to javascript
```bash
$ npm install
$ npm start
```

### Open another terminal window and serve the app on localhost:8000
```bash
$ npm run server
```

## Based off bs-platform template
This project was bootstrapped using bucklescript by running these commands
```bash
$ npm install --global bs-platform@7.0.1
$ bsb -init form-events -theme react-hooks
```
